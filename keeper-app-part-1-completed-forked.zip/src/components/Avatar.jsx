import React from "react";

function Avatar(probs) {
  return;
  <img className="circle-img" src={probs.img} alt="avatar_img" />;
}

export default Avatar;
