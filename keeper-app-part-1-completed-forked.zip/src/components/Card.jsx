import React from "react";
import contacts from "../Contacts";
import Avatar from "./Avatar";
import Detail from "./Detail";

function Card(probs) {
  return (
    <div className="card">
      <div className="top">
        <h2 className="name">{probs.name}</h2>
        <Avatar img={probs.img} />
      </div>
      <div className="bottom">
        <Detail detailinfo={probs.tel} />
        <Detail detailinfo={probs.email} />
      </div>
    </div>
  );
}

export default Card;
