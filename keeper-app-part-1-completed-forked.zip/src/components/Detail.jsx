import React from "react";

function Detail(probs) {
  return;
  <p className="info"> {probs.detailinfo} </p>;
}

export default Detail;
